from datetime import datetime
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from typing import List, Dict, Any
import os

from prompts import conduct_research_prompt, summarize_webpage_prompt
# Load env for local runs
load_dotenv('/Users/priyadwivedi/Documents/priya-exptts/jarvis/openai_sdk_deep_research/.env')

from agents import Agent, ModelSettings, Runner, function_tool
REASONING_EFFORT = 'medium'

## Tracing using Logfire
import logfire
logfire.configure(token='pylf_v1_us_7KdmWMTct8mP4FxRNKSzXNPnysff2Stb4lG5cNZyLJXs', service_name='research_agent')
logfire.instrument_openai_agents()

def _today_str() -> str:
    return datetime.now().strftime("%a %b %-d, %Y")

# Pydantic model for webpage summarization
class Summary(BaseModel):
    """Schema for webpage content summarization."""
    summary: str = Field(description="Concise summary of the webpage content")
    key_excerpts: str = Field(description="Important quotes and excerpts from the content")

class BatchSummaries(BaseModel):
    """Schema for batch webpage summarization."""
    summaries: List[Summary] = Field(description="List of summaries for each webpage")

# Utility functions for search result processing
async def batch_summarize_webpages(webpage_contents: List[str]) -> List[str]:
    """Batch summarize multiple webpage contents using GPT model.
    
    Args:
        webpage_contents: List of raw webpage contents to summarize
        
    Returns:
        List of formatted summaries with key excerpts
    """
    if not webpage_contents:
        return []
    
    try:
        # Combine all webpages into a single prompt for batch processing
        combined_content = ""
        for i, content in enumerate(webpage_contents, 1):
            # Truncate very long content to avoid token limits
            truncated_content = content[:2000] + "..." if len(content) > 2000 else content
            combined_content += f"\n\n=== WEBPAGE {i} ===\n{truncated_content}\n"
        

        # Create batch summarization prompt
        batch_prompt = f"""You are tasked with summarizing multiple webpages. For each webpage, provide a concise summary and key excerpts.

Today's date is {_today_str()}.

Here are the webpages to summarize:
{combined_content}

For each webpage, provide:
1. A concise summary (2-3 sentences) that captures the main points  
2. Key excerpts or quotes that are most relevant

Return exactly {len(webpage_contents)} summaries in the same order as the webpages."""

        # Create a simple summarization agent
        batch_summarize_agent = Agent(
            name="Batch Webpage Summarizer",
            model="gpt-5",
            model_settings=ModelSettings(reasoning_effort='low'),
            instructions=batch_prompt,
            output_type=BatchSummaries,
        )
        
        # Run the batch summarization
        summary_result = await Runner.run(batch_summarize_agent, "Summarize all these webpages")
        batch_summaries = summary_result.final_output_as(BatchSummaries)
        
        # Format the summaries
        formatted_summaries = []
        for summary_obj in batch_summaries.summaries:
            formatted_summary = (
                f"<summary>\n{summary_obj.summary}\n</summary>\n\n"
                f"<key_excerpts>\n{summary_obj.key_excerpts}\n</key_excerpts>"
            )
            formatted_summaries.append(formatted_summary)
        
        # Ensure we have the right number of summaries
        while len(formatted_summaries) < len(webpage_contents):
            formatted_summaries.append(await summarize_single_webpage(webpage_contents[len(formatted_summaries)]))
        
        return formatted_summaries[:len(webpage_contents)]
        
    except Exception as e:
        print(f"Failed to batch summarize webpages: {str(e)}")
        # Fallback to individual processing
        return [await summarize_single_webpage(content) for content in webpage_contents]

async def summarize_single_webpage(webpage_content: str) -> str:
    """Summarize single webpage content using simple truncation to avoid auth issues.
    
    Args:
        webpage_content: Raw webpage content to summarize
        
    Returns:
        Formatted summary with key excerpts
    """
    # Simple processing to avoid authentication issues in tracing
    if len(webpage_content) <= 1000:
        summary_content = webpage_content
    else:
        # Take first 800 chars to stay within reasonable limits
        summary_content = webpage_content[:800] + "..."
    
    # Format as structured output
    formatted_summary = (
        f"<summary>\n{summary_content}\n</summary>\n\n"
        f"<key_excerpts>\nContent processed for research efficiency\n</key_excerpts>"
    )
    
    return formatted_summary

def deduplicate_search_results(search_results: List[dict]) -> dict:
    """Deduplicate search results by URL to avoid processing duplicate content.
    
    Args:
        search_results: List of search result dictionaries
        
    Returns:
        Dictionary mapping URLs to unique results
    """
    unique_results = {}
    
    for response in search_results:
        for result in response['results']:
            url = result['url']
            if url not in unique_results:
                unique_results[url] = result
    
    return unique_results

async def process_search_results(unique_results: dict) -> dict:
    """Process search results by batch summarizing content where available.
    
    Args:
        unique_results: Dictionary of unique search results
        
    Returns:
        Dictionary of processed results with summaries
    """
    # Collect all raw content that needs summarization
    raw_contents = []
    urls_needing_summary = []
    
    for url, result in unique_results.items():
        if result.get("raw_content"):
            raw_contents.append(result['raw_content'])
            urls_needing_summary.append(url)
    
    # Batch summarize if we have raw content
    summaries = []
    if raw_contents:
        summaries = await batch_summarize_webpages(raw_contents)
    
    # Build final results
    summarized_results = {}
    summary_index = 0
    
    for url, result in unique_results.items():
        if result.get("raw_content") and summary_index < len(summaries):
            # Use the batch-generated summary
            content = summaries[summary_index]
            summary_index += 1
        else:
            # Use existing content
            content = result['content']
        
        summarized_results[url] = {
            'title': result['title'],
            'content': content
        }
    
    return summarized_results

def format_search_output(summarized_results: dict) -> str:
    """Format search results into a well-structured string output.
    
    Args:
        summarized_results: Dictionary of processed search results
        
    Returns:
        Formatted string of search results with clear source separation
    """
    if not summarized_results:
        return "No valid search results found. Please try different search queries or use a different search API."
    
    formatted_output = "Search results: \n\n"
    
    for i, (url, result) in enumerate(summarized_results.items(), 1):
        formatted_output += f"\n\n--- SOURCE {i}: {result['title']} ---\n"
        formatted_output += f"URL: {url}\n\n"
        formatted_output += f"SUMMARY:\n{result['content']}\n\n"
        formatted_output += "-" * 80 + "\n"
    
    return formatted_output

def tavily_search_multiple(
    search_queries: List[str], 
    max_results: int = 3, 
    topic: str = "general", 
    include_raw_content: bool = True, 
) -> List[dict]:
    """Perform search using Tavily API for multiple queries.

    Args:
        search_queries: List of search queries to execute
        max_results: Maximum number of results per query
        topic: Topic filter for search results
        include_raw_content: Whether to include raw webpage content

    Returns:
        List of search result dictionaries
    """
    from tavily import TavilyClient
    tavily_client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))
    
    # Execute searches sequentially
    search_docs = []
    for query in search_queries:
        result = tavily_client.search(
            query,
            max_results=max_results,
            include_raw_content=include_raw_content,
            topic=topic
        )
        search_docs.append(result)

    return search_docs

# Updated tavily_search tool function
@function_tool
async def tavily_search(query: str, max_results: int = 3) -> str:
    """Search the web using Tavily API with content summarization.
    
    Args:
        query: A single search query to execute
        max_results: Maximum number of results to return
        
    Returns:
        Formatted string of search results with summaries
    """
    try:
        # Execute search for single query
        search_results = tavily_search_multiple(
            [query],  # Convert single query to list for the internal function
            max_results=max_results,
            topic="general",
            include_raw_content=True,
        )
        
        # Deduplicate results by URL to avoid processing duplicate content
        unique_results = deduplicate_search_results(search_results)
        
        # Process results with summarization
        summarized_results = await process_search_results(unique_results)
        
        # Format output for consumption
        return format_search_output(summarized_results)
        
    except Exception as e:
        return f"Search failed: {str(e)}"

@function_tool
def think_tool(reflection: str) -> str:
    """Tool for strategic reflection on research progress and decision-making.
    
    Use this after each search to analyze results and plan next steps.
    
    Args:
        reflection: Your thoughts on what you found and what to do next
        
    Returns:
        Confirmation that reflection was recorded
    """
    return f"Reflection recorded: {reflection}"

# Research Agent prompt

# Create the research agent
research_agent = Agent(
    name="Research Agent",
    model="gpt-5",
    model_settings=ModelSettings(reasoning_effort=REASONING_EFFORT),
    tools=[tavily_search, think_tool],
    instructions=conduct_research_prompt.format(date=_today_str()),
)

async def conduct_research(research_question: str) -> str:
    """Conduct research on a given question using the research agent.
    
    Args:
        research_question: The question or topic to research
        
    Returns:
        Research findings as a string
    """
    if not research_question or not research_question.strip():
        return "No research question provided."
    
    try:
        # Conduct research with the agent, allowing more turns for complex research
        research_result = await Runner.run(
            research_agent, 
            research_question.strip(),
            max_turns=20  # Allow up to 20 tool calls for thorough research
        )
        return research_result.final_output
        
    except Exception as e:
        return f"Research failed: {str(e)}"

async def main(research_question: str = None):
    """Main function to run the research agent.
    
    Args:
        research_question: Optional research question. If not provided, will prompt for input.
    """
    research_result = await conduct_research(research_question)
        
    print("\n=== Research Results ===")
    print(research_result)
    
    return research_result

if __name__ == "__main__":
    import asyncio
    import sys
    
    question = '''
    I want a detailed, global review of what is factually known about UFOs/UAP from the post–WWII period (1947) to the present, with a special focus on incidents near nuclear sites (military nuclear weapons/ICBM fields, storage bunkers, SSBN bases, and civilian nuclear power plants). Limit sources to official/verified materials (declassified government and military reports, FOIA releases, official databases, sensor logs, hearing transcripts, NASA/ODNI/AARO/GEIPAN/etc. publications, and peer‑reviewed studies) plus credible eyewitness reports from trained observers (e.g., pilots, radar/sonar operators, security personnel) preferably with multi‑witness and/or multi‑sensor corroboration; avoid uncorroborated or sensational media stories, using journalism only to locate primary documents. Cover both scientific/official assessments and their conclusions (e.g., ODNI UAP reports, AARO findings, NASA’s UAP panel) and prominent unexplained cases that meet the above evidentiary bar (e.g., naval/air encounters, radar‑visual cases, restricted airspace incursions), providing citations/links. For the nuclear nexus, catalog and critically assess all documented incursions/interference events (e.g., overflights, security alerts, system anomalies/shutdowns), summarize patterns, response actions, and subsequent investigations, and note any official statements acknowledging or disputing effects. Include major countries’ official repositories and releases: United States (Project Blue Book, UAPTF/ODNI reports, AARO), United Kingdom (MoD files), France (GEIPAN), Canada (Transport Canada/CADORS), Chile (CEFAA), Brazil (FAB releases), Japan (MOD/JASDF), and any available Soviet/Russian archives; translate non‑English documents where needed. For each case, extract: date/time, location, proximity to nuclear assets, airspace status, witnesses and their roles, sensor modalities (radar/IR/EO/FLIR/SIGINT), flight characteristics, weather/astronomical context, evidence chain of custody, official explanations or resolution status, and remaining uncertainties. Provide reliability scoring (observer training, number of independent sensors, documentary provenance), categorize likely explanations (misidentification, atmospheric/astronomical, instrument/radar artifacts, balloons/drones, adversary platforms, domestic classified systems, rare plasma/EM phenomena, other), and summarize resolved vs unresolved proportions reported by official bodies. Clearly separate established facts from interpretations and hypotheses, highlight data gaps and classification barriers, and identify where high‑quality data contradicts or supports proposed explanations. Deliver a comprehensive report with an executive summary, timelines, a geo‑map of incidents (with a nuclear‑site appendix), detailed case dossiers, an evidence matrix, and a synthesis of official scientific assessments, ensuring up‑to‑date coverage through the latest releases available at the time of research.
    '''
    asyncio.run(main(research_question=question))
